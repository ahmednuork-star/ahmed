
import React, { useState, useEffect } from 'react';
import { AppView, CartItem, AppSettings } from './types';
import Hero from './components/Hero';
import ProductGrid from './components/ProductGrid';
import CourseSection from './components/CourseSection';
import AIChat from './components/AIChat';
import AdminDashboard from './components/AdminDashboard';
import LoginModal from './components/LoginModal';
import CartSidebar from './components/CartSidebar';
import { Menu, X, ShoppingBag, BookOpen, Home, User, LogIn, LogOut, Globe } from 'lucide-react';
import { storage, TRANSLATIONS } from './utils/storage';

const ADMIN_CODE = 'amkahmedamk6569';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.HOME);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [userRole, setUserRole] = useState<'guest' | 'user' | 'admin'>('guest');
  
  // New States for Features
  const [settings, setSettings] = useState<AppSettings>(storage.getSettings());
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [lang, setLang] = useState<'ar' | 'en' | 'fr'>('ar');

  const labels = TRANSLATIONS[lang];

  useEffect(() => {
    // Initial Load
    setCartItems(storage.getCart());
    const savedSettings = storage.getSettings();
    setSettings(savedSettings);
    setLang(savedSettings.appLanguage);

    if (userRole === 'guest') {
      setIsLoginModalOpen(true);
      storage.incrementVisits();
    }
  }, []);

  // Update HTML dir based on language
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const navigate = (view: AppView) => {
    setCurrentView(view);
    setMobileMenuOpen(false);
  };

  const handleAdminLogin = (code: string) => {
    if (code === ADMIN_CODE) {
      setUserRole('admin');
      navigate(AppView.ADMIN);
      return true;
    }
    return false;
  };

  const handleUserLogin = () => {
    setUserRole('user');
    setIsLoginModalOpen(false);
  };

  const handleLogout = () => {
    setUserRole('guest');
    navigate(AppView.HOME);
    setIsLoginModalOpen(true);
  };

  // Cart Functions
  const addToCart = (product: any) => {
    const updatedCart = storage.addToCart(product);
    setCartItems(updatedCart);
    setIsCartOpen(true);
  };

  const updateCartQuantity = (id: string, delta: number) => {
    const updatedCart = storage.updateCartQuantity(id, delta);
    setCartItems(updatedCart);
  };

  const removeFromCart = (id: string) => {
    const updatedCart = storage.removeFromCart(id);
    setCartItems(updatedCart);
  };

  const handleCheckout = () => {
    const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    // Save the actual order with details
    storage.addOrder(cartItems, total);
    
    alert('تم استلام طلبك بنجاح! تم إرسال التفاصيل للإدارة (المدير أحمد) وسيتواصل معك قريباً.');
    setCartItems(storage.clearCart());
    setIsCartOpen(false);
  };

  const toggleLanguage = () => {
    const nextLang = lang === 'ar' ? 'fr' : (lang === 'fr' ? 'en' : 'ar');
    setLang(nextLang);
  };

  const renderContent = () => {
    switch (currentView) {
      case AppView.HOME:
        return (
          <>
            <Hero onNavigate={() => navigate(AppView.STORE)} />
            <div className="bg-slate-900">
               <ProductGrid 
                  onAddToCart={addToCart} 
                  onOpenCart={() => setIsCartOpen(true)}
                  currency={settings.currencySymbol}
                  labels={labels}
               />
            </div>
          </>
        );
      case AppView.STORE:
        return <ProductGrid 
                  onAddToCart={addToCart} 
                  onOpenCart={() => setIsCartOpen(true)}
                  currency={settings.currencySymbol}
                  labels={labels}
               />;
      case AppView.COURSES:
        return <CourseSection />;
      case AppView.ADMIN:
        return userRole === 'admin' ? <AdminDashboard /> : <Hero onNavigate={() => navigate(AppView.STORE)} />;
      default:
        return <Hero onNavigate={() => navigate(AppView.STORE)} />;
    }
  };

  return (
    <div className={`min-h-screen bg-darker text-slate-200 font-sans selection:bg-primary selection:text-white ${lang === 'ar' ? 'font-cairo' : ''}`}>
      {/* Header */}
      <header className="sticky top-0 z-40 w-full backdrop-blur-lg bg-slate-900/80 border-b border-slate-800">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          
          {/* Logo */}
          <div 
            onClick={() => navigate(AppView.HOME)}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-8 h-8 bg-gradient-to-tr from-primary to-accent rounded-lg flex items-center justify-center transform group-hover:rotate-12 transition-transform">
              <span className="text-white font-bold text-lg">A</span>
            </div>
            <span className="font-bold text-xl text-white hidden md:block">Ahmed Tech</span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            <button onClick={() => navigate(AppView.HOME)} className={`flex items-center gap-2 text-sm font-medium transition-colors ${currentView === AppView.HOME ? 'text-primary' : 'text-slate-400 hover:text-white'}`}>
              <Home className="w-4 h-4" /> {labels.home}
            </button>
            <button onClick={() => navigate(AppView.STORE)} className={`flex items-center gap-2 text-sm font-medium transition-colors ${currentView === AppView.STORE ? 'text-primary' : 'text-slate-400 hover:text-white'}`}>
              <ShoppingBag className="w-4 h-4" /> {labels.store}
            </button>
            <button onClick={() => navigate(AppView.COURSES)} className={`flex items-center gap-2 text-sm font-medium transition-colors ${currentView === AppView.COURSES ? 'text-primary' : 'text-slate-400 hover:text-white'}`}>
              <BookOpen className="w-4 h-4" /> {labels.courses}
            </button>
            {userRole === 'admin' && (
              <button onClick={() => navigate(AppView.ADMIN)} className={`flex items-center gap-2 text-sm font-medium transition-colors ${currentView === AppView.ADMIN ? 'text-accent' : 'text-slate-400 hover:text-white'}`}>
                <User className="w-4 h-4" /> {labels.admin}
              </button>
            )}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-4">
             {/* Language Switcher */}
             <button 
                onClick={toggleLanguage}
                className="flex items-center gap-1 text-slate-400 hover:text-white text-xs font-bold border border-slate-700 rounded px-2 py-1"
             >
                <Globe className="w-3 h-3" />
                {lang.toUpperCase()}
             </button>

             {/* Cart Trigger */}
             <button 
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 text-slate-200 hover:text-primary transition-colors"
             >
                <ShoppingBag className="w-6 h-6" />
                {cartItems.length > 0 && (
                   <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-bounce">
                      {cartItems.length}
                   </span>
                )}
             </button>

            {/* Auth Button (Desktop) */}
            <div className="hidden md:block">
              {userRole === 'guest' ? (
                <button onClick={() => setIsLoginModalOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-bold transition-colors border border-slate-700">
                  <LogIn className="w-4 h-4" /> {labels.login}
                </button>
              ) : (
                <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-lg text-sm font-bold transition-colors border border-red-500/20">
                  <LogOut className="w-4 h-4" /> {labels.logout}
                </button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden p-2 text-slate-400 hover:text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-slate-900 border-b border-slate-800">
            <div className="px-4 pt-2 pb-4 space-y-1">
              <button onClick={() => navigate(AppView.HOME)} className="block w-full text-start px-3 py-2 rounded-md text-base font-medium text-slate-400 hover:bg-slate-800 hover:text-white">{labels.home}</button>
              <button onClick={() => navigate(AppView.STORE)} className="block w-full text-start px-3 py-2 rounded-md text-base font-medium text-slate-400 hover:bg-slate-800 hover:text-white">{labels.store}</button>
              <button onClick={() => navigate(AppView.COURSES)} className="block w-full text-start px-3 py-2 rounded-md text-base font-medium text-slate-400 hover:bg-slate-800 hover:text-white">{labels.courses}</button>
              {userRole === 'admin' && <button onClick={() => navigate(AppView.ADMIN)} className="block w-full text-start px-3 py-2 rounded-md text-base font-medium text-slate-400 hover:bg-slate-800 hover:text-white">{labels.admin}</button>}
              
              <div className="pt-2 mt-2 border-t border-slate-800">
                 {userRole === 'guest' ? (
                  <button onClick={() => { setMobileMenuOpen(false); setIsLoginModalOpen(true); }} className="block w-full text-start px-3 py-2 text-slate-400 hover:text-white">{labels.login}</button>
                 ) : (
                  <button onClick={handleLogout} className="block w-full text-start px-3 py-2 text-red-500 hover:text-red-400">{labels.logout}</button>
                 )}
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main>
        {renderContent()}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-slate-500 mb-2">© 2025 Ahmed Tech. All rights reserved.</p>
          <p className="text-xs text-slate-600">Designed & Developed by Ahmed Tech Team | East Chad</p>
        </div>
      </footer>

      {/* AI Assistant */}
      <AIChat />

      {/* Sidebars & Modals */}
      <CartSidebar 
         isOpen={isCartOpen}
         onClose={() => setIsCartOpen(false)}
         cartItems={cartItems}
         onUpdateQuantity={updateCartQuantity}
         onRemoveItem={removeFromCart}
         onCheckout={handleCheckout}
         currency={settings.currencySymbol}
         labels={labels}
      />

      {isLoginModalOpen && (
        <LoginModal 
          onClose={() => setIsLoginModalOpen(false)} 
          onAdminLogin={handleAdminLogin}
          onUserLogin={handleUserLogin}
        />
      )}
    </div>
  );
};

export default App;
