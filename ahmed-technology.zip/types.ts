
export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  images: string[]; // Changed from single image to array
  description: string;
}

// Backward compatibility helper
export interface LegacyProduct extends Omit<Product, 'images'> {
  image?: string;
}

export interface Course {
  id: string;
  title: string;
  instructor: string;
  duration: string;
  level: string;
  thumbnail: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isThinking?: boolean;
}

export interface CourseKey {
  code: string;
  studentName: string;
  generatedAt: string;
  isUsed: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  date: string;
  total: number;
  items: CartItem[];
  status: 'new' | 'completed';
}

export interface AppSettings {
  currencySymbol: string;
  currencyRate: number; // For future conversion if needed, default 1
  appLanguage: 'ar' | 'en' | 'fr';
}

export enum AppView {
  HOME = 'HOME',
  STORE = 'STORE',
  COURSES = 'COURSES',
  ABOUT = 'ABOUT',
  ADMIN = 'ADMIN'
}
