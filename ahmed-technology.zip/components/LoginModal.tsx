
import React, { useState } from 'react';
import { X, Lock, Mail, Chrome } from 'lucide-react';

interface LoginModalProps {
  onClose: () => void;
  onAdminLogin: (code: string) => boolean;
  onUserLogin: () => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ onClose, onAdminLogin, onUserLogin }) => {
  const [activeTab, setActiveTab] = useState<'user' | 'admin'>('user');
  const [adminCode, setAdminCode] = useState('');
  const [error, setError] = useState('');

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onAdminLogin(adminCode)) {
      onClose();
    } else {
      setError('شفرة المدير غير صحيحة');
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-slate-900 rounded-2xl w-full max-w-md border border-slate-700 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-slate-800">
          <h2 className="text-xl font-bold text-white">تسجيل الدخول</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800">
          <button
            onClick={() => setActiveTab('user')}
            className={`flex-1 py-4 text-sm font-medium transition-colors ${
              activeTab === 'user' ? 'text-primary border-b-2 border-primary bg-slate-800/50' : 'text-slate-400 hover:text-white'
            }`}
          >
            مستخدم / طالب
          </button>
          <button
            onClick={() => setActiveTab('admin')}
            className={`flex-1 py-4 text-sm font-medium transition-colors ${
              activeTab === 'admin' ? 'text-accent border-b-2 border-accent bg-slate-800/50' : 'text-slate-400 hover:text-white'
            }`}
          >
            المدير العام
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeTab === 'user' ? (
            <div className="space-y-4">
              <p className="text-slate-400 text-sm text-center mb-6">
                سجل الدخول للوصول إلى المتجر ومحفظتك الشخصية
              </p>
              
              <button 
                onClick={onUserLogin}
                className="w-full flex items-center justify-center gap-3 bg-white text-slate-900 font-bold py-3 rounded-xl hover:bg-slate-200 transition-colors"
              >
                <Chrome className="w-5 h-5 text-blue-500" />
                استخدام حساب Google
              </button>
              
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-700"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-slate-900 text-slate-500">أو</span>
                </div>
              </div>

              <form className="space-y-3">
                <input 
                  type="email" 
                  placeholder="البريد الإلكتروني" 
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary"
                />
                <button type="button" className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-xl transition-colors">
                  متابعة
                </button>
              </form>
            </div>
          ) : (
            <form onSubmit={handleAdminSubmit} className="space-y-6">
              <div className="text-center mb-4">
                 <div className="inline-flex items-center justify-center w-16 h-16 bg-slate-800 rounded-full mb-3 text-accent border border-slate-700">
                    <Lock className="w-8 h-8" />
                 </div>
                 <h3 className="text-white font-bold">وصول خاص بالمدير</h3>
                 <p className="text-xs text-slate-500 mt-1">يتطلب شفرة خاصة</p>
              </div>

              <div>
                <label className="block text-sm text-slate-400 mb-2">شفرة المدير (Admin Code)</label>
                <input 
                  type="password" 
                  value={adminCode}
                  onChange={(e) => setAdminCode(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent font-mono text-center tracking-widest"
                  placeholder="••••••••••••"
                />
                {error && <p className="text-red-500 text-xs mt-2 text-center">{error}</p>}
              </div>

              <button 
                type="submit" 
                className="w-full bg-gradient-to-r from-accent to-primary hover:opacity-90 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-accent/20"
              >
                الدخول للوحة التحكم
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};

export default LoginModal;
