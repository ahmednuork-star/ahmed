
import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { ShoppingCart, Star, PackageOpen, Eye } from 'lucide-react';
import { storage } from '../utils/storage';
import ProductDetailsModal from './ProductDetailsModal';

interface ProductGridProps {
  onAddToCart: (product: Product) => void;
  onOpenCart: () => void;
  currency: string;
  labels: any;
}

const ProductGrid: React.FC<ProductGridProps> = ({ onAddToCart, onOpenCart, currency, labels }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  useEffect(() => {
    setProducts(storage.getProducts());
  }, []);

  if (products.length === 0) {
    return (
      <div className="container mx-auto px-4 py-24 text-center">
        <div className="max-w-md mx-auto bg-slate-800/50 backdrop-blur rounded-3xl p-8 border border-slate-700">
          <div className="w-20 h-20 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-6">
            <PackageOpen className="w-10 h-10 text-slate-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-3">المتجر في طور التجهيز</h2>
          <p className="text-slate-400">
             يقوم المدير "أحمد" حالياً بإضافة أحدث المنتجات (طاقة شمسية وبطاريات، مايكروتيك، برمجة...).
            <br />
            يرجى العودة قريباً!
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-white mb-8 border-r-4 border-primary pr-4">
          {labels.products}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <div 
              key={product.id} 
              className="group bg-slate-800 rounded-2xl overflow-hidden border border-slate-700 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 cursor-pointer"
              onClick={() => setSelectedProduct(product)}
            >
              <div className="relative overflow-hidden aspect-video bg-slate-900">
                <img 
                  src={product.images?.[0] || 'https://via.placeholder.com/400x300'} 
                  alt={product.name} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md text-xs px-2 py-1 rounded text-white">
                  {product.category}
                </div>
                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                   <div className="bg-black/60 backdrop-blur px-4 py-2 rounded-full flex items-center gap-2 text-white font-bold">
                      <Eye className="w-4 h-4" />
                      {labels.viewDetails}
                   </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold text-white group-hover:text-primary transition-colors">
                    {product.name}
                  </h3>
                  <div className="flex items-center text-yellow-400 text-xs gap-1">
                    <Star className="w-3 h-3 fill-current" />
                    <span>4.9</span>
                  </div>
                </div>
                
                <p className="text-slate-400 text-sm mb-6 line-clamp-2 h-10">
                  {product.description}
                </p>
                
                <div className="flex items-center justify-between mt-auto">
                  <span className="text-2xl font-bold text-white font-mono">
                    {product.price} <span className="text-sm text-slate-400">{currency}</span>
                  </span>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddToCart(product);
                    }}
                    className="flex items-center gap-2 bg-slate-700 hover:bg-primary text-white px-4 py-2 rounded-lg transition-colors z-10"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>{labels.addToCart}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedProduct && (
        <ProductDetailsModal 
          product={selectedProduct} 
          onClose={() => setSelectedProduct(null)} 
          onAddToCart={onAddToCart}
          onOpenCart={onOpenCart}
          currency={currency}
          labels={labels}
        />
      )}
    </>
  );
};

export default ProductGrid;
