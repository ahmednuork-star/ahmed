
import React, { useState } from 'react';
import { Course } from '../types';
import { Lock, PlayCircle, ShieldCheck, PhoneCall, KeyRound, MessageSquare } from 'lucide-react';
import { storage } from '../utils/storage';

const MOCK_COURSES: Course[] = [
  {
    id: '101',
    title: 'مقدمة في الذكاء الاصطناعي',
    instructor: 'أحمد',
    duration: '12 ساعة',
    level: 'مبتدئ',
    thumbnail: 'https://picsum.photos/400/250?random=10'
  },
  {
    id: '102',
    title: 'تطوير الويب الشامل (Full Stack)',
    instructor: 'سارة',
    duration: '40 ساعة',
    level: 'متوسط',
    thumbnail: 'https://picsum.photos/400/250?random=11'
  },
  {
    id: '103',
    title: 'أمن المعلومات والشبكات',
    instructor: 'أحمد',
    duration: '25 ساعة',
    level: 'متقدم',
    thumbnail: 'https://picsum.photos/400/250?random=12'
  }
];

const CourseSection: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [accessKey, setAccessKey] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (storage.validateKey(accessKey.trim())) {
      setIsLoggedIn(true);
      setError('');
    } else {
      setError('شفرة الدخول غير صحيحة أو غير موجودة. يرجى التواصل مع الإدارة.');
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4">
        <div className="max-w-2xl w-full bg-slate-800/50 backdrop-blur-lg border border-slate-700 rounded-3xl p-8 md:p-12 shadow-2xl relative overflow-hidden text-center">
          {/* Decorative Lock Icon */}
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl"></div>
          
          <div className="mb-10 relative z-10">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-slate-700 rounded-2xl mb-6 shadow-inner border border-slate-600">
              <Lock className="w-10 h-10 text-accent" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-6 leading-relaxed">
              🎉 انطلق نحو مستقبلك التقني!
            </h2>
            <div className="space-y-2 text-lg text-slate-300 font-medium">
              <p>أهلاً بك في المكان الصحيح!</p>
              <p>أهلاً بك في متجرنا!</p>
              <p className="text-primary font-bold">ثم أهلاً بك في كورسات أحمد تكنولوجيا.</p>
            </div>
          </div>

          <div className="bg-slate-900/60 rounded-xl p-8 border border-slate-700 mb-8 text-center relative z-10">
            <h3 className="text-white font-bold mb-4 text-lg">لتسجيل الدخول والبدء في بناء مهاراتك:</h3>
            <p className="text-slate-400 text-sm mb-6">تواصل الآن مع فريقنا للحصول على الشفرة:</p>
            
            <div className="flex flex-col gap-4 mb-6">
              <div className="flex items-center justify-center gap-3 text-xl font-mono text-white font-bold bg-green-600/20 p-4 rounded-lg border border-green-500/30">
                <PhoneCall className="w-6 h-6 text-green-400" />
                <span dir="ltr">61834931</span>
                <span className="text-xs text-green-400 font-sans ml-2">(اتصال)</span>
              </div>
              
              <div className="flex items-center justify-center gap-3 text-xl font-mono text-white font-bold bg-green-500/20 p-4 rounded-lg border border-green-500/30">
                <MessageSquare className="w-6 h-6 text-green-400" />
                <span dir="ltr">23594564587</span>
                <span className="text-xs text-green-400 font-sans ml-2">(واتساب)</span>
              </div>
            </div>
            
            <p className="text-slate-300 font-medium mb-2">
              احصل على شفرة التسجيل <span className="text-accent font-mono text-sm">(Login Key)</span> الخاصة بك فوراً.
            </p>
            <p className="text-slate-300 font-medium">
              عد إلينا مباشرةً لتسجل بشفرتك وتبدأ في بناء مستقبلك!
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4 relative z-10">
            <div>
              <div className="relative">
                <KeyRound className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input
                  type="text"
                  value={accessKey}
                  onChange={(e) => setAccessKey(e.target.value)}
                  placeholder="أدخل الشفرة هنا (مثال: AHMED-X8Y2)..."
                  className="w-full bg-slate-900 border border-slate-600 rounded-xl py-3 pr-12 pl-4 text-white focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-all text-center placeholder-slate-600 font-mono uppercase"
                />
              </div>
              {error && <p className="text-red-400 text-sm mt-2 font-medium bg-red-500/10 p-2 rounded">{error}</p>}
            </div>
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/20 transition-all transform hover:scale-[1.02]"
            >
              تسجيل الدخول للكورسات
            </button>
          </form>
          
          <p className="text-center text-slate-500 text-sm mt-8 font-medium animate-pulse">
            لا تضيّع وقتك... التميز ينتظرك!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">لوحة التحكم التعليمية</h2>
          <p className="text-slate-400">مرحباً بك مرة أخرى، الطالب المجتهد.</p>
        </div>
        <div className="flex items-center gap-2 bg-green-500/10 text-green-400 px-4 py-2 rounded-lg border border-green-500/20">
          <ShieldCheck className="w-5 h-5" />
          <span className="text-sm font-medium">تم التحقق من الشفرة</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_COURSES.map((course) => (
          <div key={course.id} className="bg-slate-800 rounded-xl overflow-hidden border border-slate-700 hover:border-accent/50 transition-all group">
            <div className="relative aspect-video">
              <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm">
                <PlayCircle className="w-16 h-16 text-white drop-shadow-lg" />
              </div>
            </div>
            <div className="p-6">
              <div className="flex justify-between items-start mb-3">
                <span className="text-xs font-semibold px-2 py-1 bg-primary/20 text-primary rounded">{course.level}</span>
                <span className="text-xs text-slate-400">{course.duration}</span>
              </div>
              <h3 className="text-lg font-bold text-white mb-2">{course.title}</h3>
              <p className="text-sm text-slate-400 mb-4">المحاضر: {course.instructor}</p>
              <button className="w-full py-2 border border-slate-600 text-slate-300 rounded-lg hover:bg-slate-700 hover:text-white transition-colors">
                متابعة الدرس
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CourseSection;
