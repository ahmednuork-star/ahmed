
import React, { useState, useEffect } from 'react';
import { Users, ShoppingCart, Activity, Settings, Bell, Shield, Database, Plus, Trash2, Key, Save, Image as ImageIcon, Edit, X, Upload, RefreshCw, Phone, Globe, DollarSign, Package } from 'lucide-react';
import { storage } from '../utils/storage';
import { Product, CourseKey, AppSettings, Order } from '../types';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'content' | 'keys' | 'settings' | 'orders'>('content');
  const [products, setProducts] = useState<Product[]>([]);
  const [keys, setKeys] = useState<CourseKey[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [stats, setStats] = useState({ visits: 0, orders: 0 });
  const [settings, setSettings] = useState<AppSettings>(storage.getSettings());
  
  // Product Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [productForm, setProductForm] = useState<{
    name: string;
    price: string;
    category: string;
    images: string[];
    description: string;
  }>({
    name: '',
    price: '',
    category: '',
    images: [],
    description: ''
  });

  // Key Form State
  const [studentName, setStudentName] = useState('');

  useEffect(() => {
    // Load initial data
    setProducts(storage.getProducts());
    setKeys(storage.getKeys());
    setOrders(storage.getOrders());
    setStats(storage.getStats());
    setSettings(storage.getSettings());

    const interval = setInterval(() => {
        setStats(storage.getStats());
        setOrders(storage.getOrders());
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Settings Handlers
  const handleSettingsSave = () => {
    storage.saveSettings(settings);
    alert('تم حفظ الإعدادات بنجاح. سيتم تحديث المتجر فوراً.');
    window.location.reload(); // Reload to apply changes globally
  };

  // Product Handlers
  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (productForm.name && productForm.price) {
      // Use existing images or placeholder
      const imagesToUse = productForm.images.length > 0 
        ? productForm.images 
        : [`https://picsum.photos/400/300?random=${Date.now()}`];

      const productData: Product = {
        id: editingId || Date.now().toString(),
        name: productForm.name,
        price: parseFloat(productForm.price),
        category: productForm.category || 'عام',
        images: imagesToUse,
        description: productForm.description || 'وصف المنتج...'
      };

      if (editingId) {
        const updatedList = storage.updateProduct(productData);
        setProducts(updatedList);
        alert('تم تعديل المنتج بنجاح!');
      } else {
        const updatedList = storage.addProduct(productData);
        setProducts(updatedList);
        alert('تم نشر المنتج بنجاح على المتجر!');
      }
      
      resetProductForm();
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        // Append new image to array
        setProductForm(prev => ({ 
          ...prev, 
          images: [...prev.images, reader.result as string] 
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = (index: number) => {
    setProductForm(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const handleEditClick = (product: Product) => {
    setEditingId(product.id);
    setProductForm({
      name: product.name,
      price: product.price.toString(),
      category: product.category,
      images: product.images,
      description: product.description
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const resetProductForm = () => {
    setEditingId(null);
    setProductForm({ name: '', price: '', category: '', images: [], description: '' });
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المنتج من المتجر؟')) {
      const updatedList = storage.deleteProduct(id);
      setProducts(updatedList);
      if (editingId === id) resetProductForm();
    }
  };

  // Key Handlers
  const handleGenerateKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName) return;

    const randomCode = 'AHMED-' + Math.random().toString(36).substring(2, 7).toUpperCase();
    const newKey: CourseKey = {
      code: randomCode,
      studentName: studentName,
      generatedAt: new Date().toLocaleDateString('ar-EG'),
      isUsed: false
    };

    storage.saveKey(newKey);
    setKeys([newKey, ...keys]);
    setStudentName('');
  };

  const handleDeleteKey = (code: string) => {
    if (window.confirm('حذف هذه الشفرة سيمنع الطالب من الدخول. استمرار؟')) {
      storage.deleteKey(code);
      setKeys(keys.filter(k => k.code !== code));
    }
  };

  const handleResetStats = () => {
    if (window.confirm('هل أنت متأكد؟ سيتم تصفير عداد الزيارات والطلبات وسجل الطلبات.')) {
        storage.clearOrders();
        localStorage.setItem('ahmed_visits', '0');
        setStats({ visits: 0, orders: 0 });
        setOrders([]);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Admin Header */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 p-6 rounded-3xl border border-slate-700 mb-8 shadow-2xl">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">لوحة التحكم المركزية</h1>
            <p className="text-slate-400 flex items-center gap-2">
              <span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.5)]"></span>
              مرحباً بالمدير أحمد - العقل المدبر
            </p>
          </div>
          <div className="flex gap-4">
             <button 
                onClick={handleResetStats}
                className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-xl border border-red-500/20 transition-colors"
             >
                <RefreshCw size={14} />
                تصفير الكل
             </button>
             <div className="text-center px-4 py-2 bg-slate-800 rounded-xl border border-slate-700">
                <span className="block text-xs text-slate-500">العملة الحالية</span>
                <span className="text-accent font-bold text-sm">{settings.currencySymbol}</span>
             </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg"><Users size={20} /></div>
            <span className="text-slate-400 text-sm">الزوار</span>
          </div>
          <p className="text-3xl font-bold text-white">{stats.visits}</p>
        </div>
        
        <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-green-500/20 text-green-400 rounded-lg"><ShoppingCart size={20} /></div>
            <span className="text-slate-400 text-sm">إجمالي الطلبات</span>
          </div>
          <p className="text-3xl font-bold text-white">{stats.orders}</p>
        </div>

        <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
           <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-purple-500/20 text-purple-400 rounded-lg"><Database size={20} /></div>
            <span className="text-slate-400 text-sm">المنتجات</span>
          </div>
          <p className="text-3xl font-bold text-white">{products.length}</p>
        </div>

        <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-yellow-500/20 text-yellow-400 rounded-lg"><Shield size={20} /></div>
            <span className="text-slate-400 text-sm">أمان النظام</span>
          </div>
          <p className="text-xl font-bold text-white">100%</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-6 bg-slate-800 p-1 rounded-xl w-fit border border-slate-700">
        <button 
          onClick={() => setActiveTab('content')}
          className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'content' ? 'bg-primary text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
        >
          إدارة المنتجات
        </button>
        <button 
          onClick={() => setActiveTab('orders')}
          className={`px-6 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'orders' ? 'bg-green-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
        >
          الطلبات الواردة
          {orders.length > 0 && <span className="bg-red-500 text-white text-xs px-1.5 rounded-full">{orders.length}</span>}
        </button>
        <button 
          onClick={() => setActiveTab('keys')}
          className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'keys' ? 'bg-accent text-slate-900 shadow-lg' : 'text-slate-400 hover:text-white'}`}
        >
          شفرات الكورسات
        </button>
        <button 
          onClick={() => setActiveTab('settings')}
          className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'settings' ? 'bg-slate-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
        >
          الإعدادات (Settings)
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Main Panel */}
        <div className="lg:col-span-2">
          {activeTab === 'content' && (
            <div className="space-y-6">
              {/* Product Form */}
              <div className={`bg-slate-800 rounded-2xl border ${editingId ? 'border-yellow-500/50' : 'border-slate-700'} p-6 transition-colors`}>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold text-white flex items-center gap-2">
                    {editingId ? <Edit className="w-5 h-5 text-yellow-500" /> : <Plus className="w-5 h-5 text-green-500" />}
                    {editingId ? 'تعديل منتج حالي' : 'إضافة منتج جديد'}
                  </h3>
                  {editingId && (
                    <button onClick={resetProductForm} className="text-slate-400 hover:text-white text-sm flex items-center gap-1">
                      <X className="w-4 h-4" /> إلغاء
                    </button>
                  )}
                </div>

                <form onSubmit={handleProductSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input 
                      type="text" 
                      placeholder="اسم المنتج"
                      value={productForm.name}
                      onChange={e => setProductForm({...productForm, name: e.target.value})}
                      className="bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary"
                    />
                    <div className="relative">
                      <input 
                        type="number" 
                        placeholder="السعر"
                        value={productForm.price}
                        onChange={e => setProductForm({...productForm, price: e.target.value})}
                        className="w-full bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary pl-16"
                      />
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold border-l border-slate-700 pl-2">
                        {settings.currencySymbol}
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <div className="relative">
                        <input 
                        type="text" 
                        placeholder="القسم (طاقة شمسية، برمجة، واي فاي...)"
                        value={productForm.category}
                        onChange={e => setProductForm({...productForm, category: e.target.value})}
                        className="w-full bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary"
                        list="categories"
                        />
                        <datalist id="categories">
                           <option value="طاقة شمسية وبطاريات" />
                           <option value="برمجة أجهزة" />
                           <option value="أجهزة واي فاي" />
                           <option value="مايكروتيك" />
                           <option value="كابلات إيثرنت" />
                           <option value="لابتوب" />
                        </datalist>
                     </div>

                    <div className="relative">
                      <input 
                        type="file" 
                        accept="image/*"
                        id="image-upload"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      <label 
                        htmlFor="image-upload"
                        className="flex items-center justify-center gap-2 w-full bg-slate-900 border border-slate-600 border-dashed hover:border-primary hover:text-primary rounded-xl px-4 py-3 text-slate-400 cursor-pointer transition-colors"
                      >
                         <Upload className="w-5 h-5" />
                         <span>إضافة صورة للمعرض</span>
                      </label>
                    </div>
                  </div>

                  {/* Image Previews */}
                  {productForm.images.length > 0 && (
                      <div className="flex gap-2 overflow-x-auto py-2">
                          {productForm.images.map((img, idx) => (
                              <div key={idx} className="relative w-20 h-20 flex-shrink-0 group">
                                  <img src={img} alt="Preview" className="w-full h-full object-cover rounded-lg border border-slate-600" />
                                  <button 
                                    type="button"
                                    onClick={() => removeImage(idx)}
                                    className="absolute top-0 right-0 bg-red-500 text-white rounded-bl-lg p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                  >
                                    <X size={12} />
                                  </button>
                              </div>
                          ))}
                      </div>
                  )}

                  <textarea 
                    placeholder="وصف المنتج وتفاصيله الفنية..."
                    value={productForm.description}
                    onChange={e => setProductForm({...productForm, description: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary h-24 resize-none"
                  ></textarea>

                  <button type="submit" className={`w-full ${editingId ? 'bg-yellow-600 hover:bg-yellow-500' : 'bg-primary hover:bg-primary/90'} text-white py-3 rounded-xl font-bold transition-colors flex items-center justify-center gap-2`}>
                    <Save className="w-5 h-5" />
                    {editingId ? 'حفظ التعديلات' : 'نشر المنتج'}
                  </button>
                </form>
              </div>

              {/* List */}
              <div className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden">
                <div className="p-4 bg-slate-900/50 border-b border-slate-700"><h3 className="font-bold text-white">المنتجات الحالية</h3></div>
                <div className="p-4 space-y-3 max-h-[500px] overflow-y-auto">
                  {products.map((p) => (
                    <div key={p.id} className="flex items-center justify-between p-3 bg-slate-900 rounded-xl border border-slate-700">
                      <div className="flex items-center gap-3">
                        <img src={p.images?.[0]} alt={p.name} className="w-12 h-12 rounded-lg object-cover bg-slate-800" />
                        <div>
                          <h4 className="text-white font-bold text-sm">{p.name}</h4>
                          <span className="text-accent text-xs font-mono">{p.price} {settings.currencySymbol}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => handleEditClick(p)} className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-lg"><Edit className="w-5 h-5" /></button>
                        <button onClick={() => handleDeleteProduct(p.id)} className="p-2 text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="w-5 h-5" /></button>
                      </div>
                    </div>
                  ))}
                  {products.length === 0 && <p className="text-center text-slate-500 py-8">المتجر فارغ</p>}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
             <div className="space-y-6">
                 <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6">
                    <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                       <Package className="w-5 h-5 text-green-500" />
                       سجل الطلبات الواردة
                    </h3>
                    <div className="space-y-4">
                       {orders.length === 0 ? (
                          <div className="text-center py-10 text-slate-500 border-2 border-dashed border-slate-700 rounded-xl">
                             <ShoppingCart className="w-10 h-10 mx-auto mb-2 opacity-50" />
                             لا توجد طلبات جديدة
                          </div>
                       ) : (
                          orders.map((order) => (
                             <div key={order.id} className="bg-slate-900 border border-slate-700 rounded-xl p-4">
                                <div className="flex justify-between items-start border-b border-slate-800 pb-2 mb-2">
                                   <div>
                                      <span className="text-xs text-slate-500 font-mono">#{order.id}</span>
                                      <p className="text-white text-sm">{order.date}</p>
                                   </div>
                                   <div className="text-left">
                                      <span className="text-accent font-bold font-mono text-lg">{order.total} {settings.currencySymbol}</span>
                                   </div>
                                </div>
                                <div className="space-y-2">
                                   {order.items.map((item, idx) => (
                                      <div key={idx} className="flex justify-between items-center text-sm">
                                         <div className="flex items-center gap-2">
                                            <span className="bg-slate-800 text-white px-2 rounded text-xs">x{item.quantity}</span>
                                            <span className="text-slate-300">{item.name}</span>
                                         </div>
                                         <span className="text-slate-500 text-xs">{item.price * item.quantity}</span>
                                      </div>
                                   ))}
                                </div>
                             </div>
                          ))
                       )}
                    </div>
                 </div>
             </div>
          )}

          {activeTab === 'keys' && (
            <div className="space-y-6">
              <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6">
                <h3 className="font-bold text-white mb-4 flex items-center gap-2"><Key className="w-5 h-5 text-accent" /> توليد شفرة</h3>
                <form onSubmit={handleGenerateKey} className="flex gap-4">
                  <input 
                    type="text" placeholder="اسم الطالب" value={studentName} onChange={(e) => setStudentName(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent"
                  />
                  <button type="submit" className="bg-accent hover:bg-accent/90 text-slate-900 px-6 py-3 rounded-xl font-bold">توليد</button>
                </form>
              </div>
              <div className="bg-slate-800 rounded-2xl border border-slate-700 p-4">
                  <div className="divide-y divide-slate-700">
                    {keys.map((k) => (
                        <div key={k.code} className="py-3 flex justify-between items-center">
                            <div>
                                <p className="text-white font-mono font-bold">{k.code}</p>
                                <p className="text-xs text-slate-400">{k.studentName}</p>
                            </div>
                            <button onClick={() => handleDeleteKey(k.code)} className="text-red-400 p-2"><Trash2 size={18} /></button>
                        </div>
                    ))}
                    {keys.length === 0 && <p className="text-slate-500 text-center">لا توجد شفرات</p>}
                  </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6 space-y-6">
               <h3 className="font-bold text-white text-xl border-b border-slate-700 pb-4">إعدادات التطبيق العامة</h3>
               
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div>
                    <label className="block text-slate-400 mb-2 flex items-center gap-2">
                       <DollarSign className="w-4 h-4" />
                       العملة الافتراضية
                    </label>
                    <input 
                      type="text"
                      value={settings.currencySymbol}
                      onChange={(e) => setSettings({...settings, currencySymbol: e.target.value})}
                      className="w-full bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white focus:border-primary outline-none"
                      placeholder="مثال: FCFA, USD, SDG"
                    />
                    <p className="text-xs text-slate-500 mt-2">ستظهر هذه العملة بجانب كل الأسعار في المتجر.</p>
                 </div>

                 <div>
                    <label className="block text-slate-400 mb-2 flex items-center gap-2">
                       <Globe className="w-4 h-4" />
                       لغة التطبيق الافتراضية
                    </label>
                    <select 
                      value={settings.appLanguage}
                      onChange={(e) => setSettings({...settings, appLanguage: e.target.value as any})}
                      className="w-full bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white focus:border-primary outline-none"
                    >
                       <option value="ar">العربية (Arabic)</option>
                       <option value="en">English (الإنجليزية)</option>
                       <option value="fr">Français (الفرنسية)</option>
                    </select>
                    <p className="text-xs text-slate-500 mt-2">اللغة التي سيبدأ بها التطبيق للزوار الجدد.</p>
                 </div>
               </div>

               <div className="pt-4 border-t border-slate-700">
                  <button 
                    onClick={handleSettingsSave}
                    className="w-full md:w-auto px-8 py-3 bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2"
                  >
                     <Save className="w-5 h-5" />
                     حفظ وتطبيق التغييرات
                  </button>
               </div>
            </div>
          )}
        </div>

        {/* Info Sidebar */}
        <div className="lg:col-span-1 space-y-6">
           <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-6 rounded-2xl border border-primary/20">
              <h3 className="font-bold text-white mb-4 flex items-center gap-2"><Phone className="w-5 h-5 text-accent" /> الدعم الفني</h3>
              <div className="space-y-3">
                 <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700 flex justify-between"><span className="text-slate-300">اتصال</span><span className="font-mono text-accent" dir="ltr">61834931</span></div>
                 <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700 flex justify-between"><span className="text-slate-300">واتساب</span><span className="font-mono text-green-400" dir="ltr">23594564587</span></div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
