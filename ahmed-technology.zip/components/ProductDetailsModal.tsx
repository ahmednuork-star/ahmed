
import React, { useState } from 'react';
import { Product } from '../types';
import { X, ShoppingCart, ChevronRight, ChevronLeft, Zap } from 'lucide-react';

interface ProductDetailsModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  onOpenCart: () => void;
  currency: string;
  labels: any;
}

const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({ 
  product, 
  onClose, 
  onAddToCart,
  onOpenCart,
  currency,
  labels 
}) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  const images = product.images && product.images.length > 0 
    ? product.images 
    : ['https://via.placeholder.com/400x300?text=No+Image'];

  const nextImage = () => {
    setActiveImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setActiveImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const handleBuyNow = () => {
    onAddToCart(product);
    onClose();
    onOpenCart();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 md:p-4 bg-black/90 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 rounded-none md:rounded-2xl w-full max-w-5xl border-0 md:border border-slate-700 shadow-2xl overflow-hidden flex flex-col md:flex-row h-full md:h-auto md:max-h-[90vh]">
        
        {/* Mobile Header (Close Button) */}
        <button 
            onClick={onClose} 
            className="md:hidden absolute top-4 left-4 z-20 p-2 bg-black/50 text-white rounded-full backdrop-blur-sm"
        >
            <X className="w-6 h-6" />
        </button>

        {/* Image Gallery Section */}
        <div className="w-full md:w-1/2 bg-black relative flex flex-col h-[40vh] md:h-auto shrink-0">
          <div className="relative flex-1 overflow-hidden flex items-center justify-center bg-slate-950">
            <img 
              src={images[activeImageIndex]} 
              alt={product.name} 
              className="max-w-full max-h-full object-contain"
            />
            
            {images.length > 1 && (
              <>
                <button 
                  onClick={prevImage}
                  className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button 
                  onClick={nextImage}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </>
            )}
            
            {/* Image Counter Badge */}
            <div className="absolute bottom-4 right-4 bg-black/60 text-white px-3 py-1 rounded-full text-xs font-mono">
                {activeImageIndex + 1} / {images.length}
            </div>
          </div>
          
          {/* Thumbnails (Desktop Only) */}
          {images.length > 1 && (
            <div className="hidden md:flex p-4 gap-2 overflow-x-auto bg-slate-950/50 border-t border-slate-800">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-16 h-16 rounded-lg border-2 overflow-hidden flex-shrink-0 transition-all ${activeImageIndex === idx ? 'border-primary ring-2 ring-primary/30' : 'border-slate-700 opacity-60 hover:opacity-100'}`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Content Section */}
        <div className="w-full md:w-1/2 flex flex-col h-[60vh] md:h-auto bg-slate-900">
          
          {/* Desktop Close Button */}
          <div className="hidden md:flex justify-end p-4 pb-0">
             <button onClick={onClose} className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors">
               <X className="w-5 h-5" />
             </button>
          </div>

          <div className="p-6 md:p-8 overflow-y-auto flex-1 custom-scrollbar">
            <span className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-bold mb-3 border border-primary/20">
              {product.category}
            </span>
            <h2 className="text-2xl md:text-3xl font-bold text-white leading-tight mb-4">
              {product.name}
            </h2>
            
            <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 mb-6">
                <h3 className="text-slate-400 text-sm font-bold mb-2 uppercase tracking-wider">{labels.description}</h3>
                <p className="text-slate-300 leading-relaxed text-base whitespace-pre-wrap">
                {product.description}
                </p>
            </div>
          </div>

          {/* Bottom Action Bar (Sticky/Fixed) */}
          <div className="p-4 md:p-6 bg-slate-800 border-t border-slate-700 shadow-[0_-5px_20px_rgba(0,0,0,0.3)] z-10">
            <div className="flex items-center justify-between mb-4">
                 <div>
                    <span className="text-slate-400 text-xs block mb-1">{labels.price}</span>
                    <span className="text-3xl font-bold text-white font-mono flex items-baseline gap-1">
                        {product.price} 
                        <span className="text-sm text-accent font-sans">{currency}</span>
                    </span>
                 </div>
            </div>

            <div className="flex gap-3">
                <button 
                  onClick={() => onAddToCart(product)}
                  className="flex-1 py-3.5 bg-slate-700 hover:bg-slate-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span className="text-sm md:text-base">{labels.addToCart}</span>
                </button>
                
                <button 
                  onClick={handleBuyNow}
                  className="flex-[1.5] py-3.5 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-green-500/20 transition-all transform active:scale-95"
                >
                  <Zap className="w-5 h-5 fill-current" />
                  <span className="text-sm md:text-base">{labels.buyNow}</span>
                </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailsModal;
