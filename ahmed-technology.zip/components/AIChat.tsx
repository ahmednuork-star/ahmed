
import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Cpu, Loader2, Sparkles } from 'lucide-react';
import { sendMessageToGemini } from '../services/geminiService';
import { ChatMessage } from '../types';
import ReactMarkdown from 'react-markdown';

const AIChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      text: 'مرحباً! أنا "الشريك الذكي" لأحمد تكنولوجيا. كيف يمكنني مساعدتك اليوم في المتجر أو الكورسات؟',
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', text: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      // Create a placeholder for the model response
      const modelMsgPlaceholder: ChatMessage = { role: 'model', text: '', timestamp: new Date(), isThinking: true };
      setMessages(prev => [...prev, modelMsgPlaceholder]);

      const stream = await sendMessageToGemini(messages, userMsg.text);
      
      let fullText = '';
      
      for await (const chunk of stream) {
        fullText += chunk;
        setMessages(prev => {
          const newHistory = [...prev];
          const lastMsg = newHistory[newHistory.length - 1];
          // Update the last message (the model placeholder)
          if (lastMsg.role === 'model') {
            lastMsg.text = fullText;
            lastMsg.isThinking = false;
          }
          return newHistory;
        });
      }
    } catch (error) {
      setMessages(prev => [
        ...prev,
        { role: 'model', text: 'عذراً، حدث خطأ في الاتصال. يرجى المحاولة لاحقاً.', timestamp: new Date() }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleArchitectureQuestion = () => {
    const question = `⚙ السؤال النهائي: هندسة البنية التحتية المتكاملة
"بناءً على المتطلبات التفصيلية لتطبيق 'أحمد تكنولوجيا' (متجر إلكتروني بنمط علي بابا + كورسات مخصصة لمخيم قاقا بشرق تشاد)، والذي يجمع بين الأمان المشدد والابتكار:
ما هي الهندسة المعمارية (Architecture) المثلى (هل نعتمد على Microservices لضمان قابلية التوسع، أم Monolith؟) التي يجب تبنيها لدعم هذه الميزات؟
كيف يتم بناء البنية التحتية للخلفية (Backend Infrastructure) لضمان الأمان التام لنظام شفرات الدخول المتعددة للمدير، مع إمكانية التكامل السلس والآمن لمساعد الذكاء الاصطناعي (AI Partner) مباشرة ضمن لوحة التحكم الإدارية؟
ما هي متطلبات قاعدة البيانات (Database) المقترحة (SQL vs. NoSQL) التي تناسب متجراً ضخماً وفي نفس الوقت تدعم التحديثات الفورية المطلوبة لنظام الدردشة وتسجيل الكورسات الفريد؟
الهدف: تصميم بنية تحتية قوية ومُتكيفة تستطيع إدارة الأمان، والذكاء الاصطناعي، والعمليات التجارية في وقت واحد."`;
    
    setInput(question);
  };

  return (
    <>
      {/* Floating Trigger Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 left-6 z-50 flex items-center gap-2 bg-gradient-to-r from-accent to-primary p-4 rounded-full shadow-lg shadow-primary/30 transition-all hover:scale-110 ${isOpen ? 'hidden' : 'flex'}`}
      >
        <Sparkles className="w-6 h-6 text-white animate-pulse" />
        <span className="hidden md:inline font-bold text-white">المساعد الذكي</span>
      </button>

      {/* Chat Interface */}
      {isOpen && (
        <div className="fixed bottom-6 left-6 z-50 w-[90vw] md:w-[400px] h-[600px] max-h-[80vh] bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-300">
          {/* Header */}
          <div className="bg-slate-800 p-4 border-b border-slate-700 flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Cpu className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">أحمد AI</h3>
                <span className="text-xs text-green-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400"></span>
                  متصل الآن
                </span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-900/95">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div 
                  className={`max-w-[85%] rounded-2xl p-3 text-sm leading-relaxed ${
                    msg.role === 'user' 
                      ? 'bg-primary text-white rounded-br-none' 
                      : 'bg-slate-800 text-slate-200 border border-slate-700 rounded-bl-none'
                  }`}
                >
                  {msg.isThinking ? (
                     <div className="flex items-center gap-2 text-slate-400">
                       <Loader2 className="w-4 h-4 animate-spin" />
                       <span>يفكر...</span>
                     </div>
                  ) : (
                    <div className="prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown>{msg.text}</ReactMarkdown>
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggested Actions (Quick Prompts) */}
          {!isLoading && messages.length < 3 && (
            <div className="px-4 py-2 flex gap-2 overflow-x-auto no-scrollbar">
              <button 
                onClick={handleArchitectureQuestion}
                className="whitespace-nowrap px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-full text-xs text-accent transition-colors"
              >
                ⚙️ السؤال الهندسي المتكامل
              </button>
              <button 
                onClick={() => setInput('كيف أحصل على شفرة الكورسات؟')}
                className="whitespace-nowrap px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-full text-xs text-primary transition-colors"
              >
                📚 شفرة الكورسات
              </button>
            </div>
          )}

          {/* Input Area */}
          <div className="p-4 bg-slate-800 border-t border-slate-700">
            <div className="relative">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="اكتب رسالتك هنا..."
                disabled={isLoading}
                className="w-full bg-slate-900 border border-slate-600 text-white rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary disabled:opacity-50 min-h-[50px] max-h-[120px] resize-none"
              />
              <button 
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 bg-primary text-white rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:hover:bg-primary transition-colors"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AIChat;
