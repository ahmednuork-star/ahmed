
import React from 'react';
import { ArrowLeft, Cpu, Globe, Zap } from 'lucide-react';

interface HeroProps {
  onNavigate: () => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <div className="relative overflow-hidden bg-darker py-16 sm:py-24 lg:py-32">
      {/* Background Effects */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[100px] opacity-50 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-[400px] h-[400px] bg-secondary/20 rounded-full blur-[100px] opacity-50 pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-800/50 border border-slate-700 mb-8 backdrop-blur-sm animate-pulse-slow">
          <span className="w-2 h-2 rounded-full bg-green-500"></span>
          <span className="text-sm font-medium text-slate-300">المنصة تعمل بكامل كفاءتها</span>
        </div>

        <h1 className="text-4xl md:text-6xl lg:text-7xl font-black text-white mb-6 leading-tight">
          <span className="block text-2xl md:text-4xl mb-4 font-light text-slate-300">
             👋 أهلاً ومرحباً بك في عالمنا!
          </span>
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-secondary">
            أحمد تكنولوجيا
          </span>
        </h1>

        <div className="max-w-3xl mx-auto text-lg md:text-xl text-slate-300 mb-10 leading-relaxed bg-slate-900/40 p-6 rounded-2xl border border-slate-800/50 backdrop-blur-sm">
          <p className="mb-4">
            نحن نرحب بك في وجهتك الجديدة المتميزة، التي تم إعدادها وتقديمها خصيصاً برؤية المدير:
          </p>
          <p className="text-2xl font-bold text-accent mb-6">
            ✨ أحمد - رائد التكنولوجيا ✨
          </p>
          <p className="mb-2 font-semibold text-white">انضم إلينا في رحلة استكشاف:</p>
          <ul className="list-none space-y-2 mb-4 text-slate-400">
            <li className="flex items-center justify-center gap-2">
              <span className="text-primary">🚀</span> أحدث المنتجات/الحلول التكنولوجية.
            </li>
            <li className="flex items-center justify-center gap-2">
              <span className="text-yellow-400">💡</span> رؤى مبتكرة وخبرة متراكمة.
            </li>
          </ul>
          <p className="font-medium text-white">
            نتطلع لخدمتك وإثراء تجربتك معنا!
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button 
            onClick={onNavigate}
            className="group relative px-8 py-4 bg-primary hover:bg-primary/90 text-white font-bold rounded-xl transition-all shadow-lg shadow-primary/25 overflow-hidden"
          >
            <div className="absolute inset-0 w-full h-full bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out"></div>
            <span className="relative flex items-center gap-2">
              تصفح المتجر الآن
              <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            </span>
          </button>
          
          <div className="grid grid-cols-3 gap-6 text-slate-400 mt-8 sm:mt-0 sm:mr-8 border-r border-slate-700 pr-8">
            <div className="flex flex-col items-center gap-1">
              <Zap className="w-6 h-6 text-yellow-400" />
              <span className="text-xs">سرعة</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <Cpu className="w-6 h-6 text-accent" />
              <span className="text-xs">ابتكار</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <Globe className="w-6 h-6 text-primary" />
              <span className="text-xs">تواصل</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
