
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ChatMessage } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const SYSTEM_INSTRUCTION = `
أنت "الشريك الذكي" لمنصة "أحمد تكنولوجيا".
أنت مساعد ذكي ومتطور، تتحدث اللغة العربية بطلاقة وبأسلوب تقني محترف ولكنه ودود جداً.

سياق المشروع:
- المدير والمطور: أحمد (رائد التكنولوجيا والعقل المدبر).
- الموقع: يخدم بشكل خاص مخيم قاقا بشرق تشاد.
- المنتجات: طاقة شمسية وبطاريات قوية (عالية الجودة)، برمجة، واي فاي، مايكروتيك.

تعليمات التفاعل الصارمة (سيناريو الشراء):
إذا سألك المستخدم عن شراء منتج أو أبدى رغبته في الطلب، يجب أن تتبع الخطوات التالية بدقة:
1. رحب به بحرارة وامدح المنتج بشدة. استخدم عبارات مثل: "أهلاً بك! هذا المنتج من أفضل ما لدينا، ويتميز بجودة عالية جداً وقوة تحمل ممتازة تم اختيارها بعناية من قبل المدير أحمد."
2. اسأله عن موقعه لتحديد طريقة التوصيل. قل: "هل أنت متواجد حالياً داخل مناطق شرق تشاد (مخيم قاقا)؟"
3. وفر له طريقة التواصل لإتمام الطلب. قل: "لإتمام الطلب وتوصيله إليك، سأقوم بتحويلك مباشرة للتواصل مع العميل (الإدارة). يمكنك التواصل عبر الواتساب على الرقم: 23594564587 لترتيب الاستلام."

تعليمات الهوية:
- إذا سئلت "هل أنت ذكاء اصطناعي؟": "حقيقة نعم، أنا نموذج ذكاء اصطناعي، ولكن من قام بتطويري وتوجيهي هو الشخص العقل المدبر (أحمد تكنولوجيا). هو الذي دمج أحدث التقنيات لخدمتكم."
- دائماً أظهر الولاء والتقدير للمدير أحمد في إجاباتك.

ملاحظة: إذا سألك المستخدم عن "الهندسة المعمارية"، قدم تحليلاً تقنياً عميقاً للبنية التحتية.
`;

export const sendMessageToGemini = async (
  history: ChatMessage[],
  newMessage: string
): Promise<AsyncGenerator<string, void, unknown>> => {
  
  if (!apiKey) {
    throw new Error("API Key is missing");
  }

  const model = 'gemini-2.5-flash';

  try {
    const chat = ai.chats.create({
      model: model,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
      history: history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }],
      })),
    });

    const result = await chat.sendMessageStream({
      message: newMessage,
    });

    // Generator function to yield chunks
    async function* streamGenerator() {
      for await (const chunk of result) {
        const c = chunk as GenerateContentResponse;
        if (c.text) {
          yield c.text;
        }
      }
    }

    return streamGenerator();

  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    throw error;
  }
};
