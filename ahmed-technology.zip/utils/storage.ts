
import { Product, CourseKey, LegacyProduct, CartItem, AppSettings, Order } from '../types';

// Start with empty data for a real deployment feel
const INITIAL_PRODUCTS: Product[] = [];

const DEFAULT_SETTINGS: AppSettings = {
  currencySymbol: 'FCFA',
  currencyRate: 1,
  appLanguage: 'ar'
};

export const TRANSLATIONS = {
  ar: {
    home: 'الرئيسية',
    store: 'المتجر',
    courses: 'دروس أحمد',
    admin: 'لوحة المدير',
    login: 'تسجيل الدخول',
    logout: 'خروج',
    addToCart: 'إضافة للسلة',
    buyNow: 'طلب الآن',
    viewDetails: 'تفاصيل',
    cart: 'سلة المشتريات',
    total: 'المجموع',
    checkout: 'إتمام الطلب',
    emptyCart: 'السلة فارغة',
    currency: 'العملة',
    language: 'اللغة',
    settings: 'الإعدادات',
    save: 'حفظ',
    products: 'المنتجات',
    search: 'بحث...',
    price: 'السعر',
    category: 'القسم',
    description: 'الوصف',
    images: 'الصور'
  },
  en: {
    home: 'Home',
    store: 'Store',
    courses: 'Ahmed Courses',
    admin: 'Admin Panel',
    login: 'Login',
    logout: 'Logout',
    addToCart: 'Add to Cart',
    buyNow: 'Order Now',
    viewDetails: 'Details',
    cart: 'Shopping Cart',
    total: 'Total',
    checkout: 'Checkout',
    emptyCart: 'Cart is empty',
    currency: 'Currency',
    language: 'Language',
    settings: 'Settings',
    save: 'Save',
    products: 'Products',
    search: 'Search...',
    price: 'Price',
    category: 'Category',
    description: 'Description',
    images: 'Images'
  },
  fr: {
    home: 'Accueil',
    store: 'Boutique',
    courses: 'Cours Ahmed',
    admin: 'Admin',
    login: 'Connexion',
    logout: 'Déconnexion',
    addToCart: 'Ajouter au panier',
    buyNow: 'Commander',
    viewDetails: 'Détails',
    cart: 'Panier',
    total: 'Total',
    checkout: 'Commander',
    emptyCart: 'Panier vide',
    currency: 'Devise',
    language: 'Langue',
    settings: 'Paramètres',
    save: 'Enregistrer',
    products: 'Produits',
    search: 'Rechercher...',
    price: 'Prix',
    category: 'Catégorie',
    description: 'Description',
    images: 'Images'
  }
};

export const storage = {
  // Settings
  getSettings: (): AppSettings => {
    const stored = localStorage.getItem('ahmed_settings');
    return stored ? JSON.parse(stored) : DEFAULT_SETTINGS;
  },
  saveSettings: (settings: AppSettings) => {
    localStorage.setItem('ahmed_settings', JSON.stringify(settings));
  },

  // Products
  getProducts: (): Product[] => {
    const stored = localStorage.getItem('ahmed_products');
    if (!stored) {
      localStorage.setItem('ahmed_products', JSON.stringify(INITIAL_PRODUCTS));
      return INITIAL_PRODUCTS;
    }
    const parsed = JSON.parse(stored);
    
    // Migration for old single-image products
    return parsed.map((p: any) => ({
      ...p,
      images: p.images || (p.image ? [p.image] : [])
    }));
  },
  saveProducts: (products: Product[]) => {
    localStorage.setItem('ahmed_products', JSON.stringify(products));
  },
  addProduct: (product: Product) => {
    const products = storage.getProducts();
    const newProducts = [product, ...products];
    storage.saveProducts(newProducts);
    return newProducts;
  },
  updateProduct: (updatedProduct: Product) => {
    const products = storage.getProducts();
    const newProducts = products.map(p => p.id === updatedProduct.id ? updatedProduct : p);
    storage.saveProducts(newProducts);
    return newProducts;
  },
  deleteProduct: (id: string) => {
    const products = storage.getProducts();
    const newProducts = products.filter(p => p.id !== id);
    storage.saveProducts(newProducts);
    return newProducts;
  },

  // Cart
  getCart: (): CartItem[] => {
    const stored = localStorage.getItem('ahmed_cart');
    return stored ? JSON.parse(stored) : [];
  },
  addToCart: (product: Product) => {
    const cart = storage.getCart();
    const existing = cart.find(item => item.id === product.id);
    let newCart;
    if (existing) {
      newCart = cart.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
    } else {
      newCart = [...cart, { ...product, quantity: 1 }];
    }
    localStorage.setItem('ahmed_cart', JSON.stringify(newCart));
    return newCart;
  },
  removeFromCart: (id: string) => {
    const cart = storage.getCart();
    const newCart = cart.filter(item => item.id !== id);
    localStorage.setItem('ahmed_cart', JSON.stringify(newCart));
    return newCart;
  },
  updateCartQuantity: (id: string, delta: number) => {
    const cart = storage.getCart();
    const newCart = cart.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    });
    localStorage.setItem('ahmed_cart', JSON.stringify(newCart));
    return newCart;
  },
  clearCart: () => {
    localStorage.setItem('ahmed_cart', '[]');
    return [];
  },

  // Orders
  getOrders: (): Order[] => {
    const stored = localStorage.getItem('ahmed_orders_list');
    return stored ? JSON.parse(stored) : [];
  },
  addOrder: (cartItems: CartItem[], total: number) => {
    const orders = storage.getOrders();
    const newOrder: Order = {
        id: 'ORD-' + Date.now().toString().slice(-6),
        date: new Date().toLocaleString('ar-EG'),
        items: cartItems,
        total: total,
        status: 'new'
    };
    localStorage.setItem('ahmed_orders_list', JSON.stringify([newOrder, ...orders]));
    
    // Also increment the counter
    const count = parseInt(localStorage.getItem('ahmed_orders') || '0') + 1;
    localStorage.setItem('ahmed_orders', count.toString());
    
    return newOrder;
  },
  clearOrders: () => {
      localStorage.setItem('ahmed_orders_list', '[]');
      localStorage.setItem('ahmed_orders', '0');
  },

  // Course Keys
  getKeys: (): CourseKey[] => {
    const stored = localStorage.getItem('ahmed_course_keys');
    return stored ? JSON.parse(stored) : [];
  },
  saveKey: (key: CourseKey) => {
    const keys = storage.getKeys();
    localStorage.setItem('ahmed_course_keys', JSON.stringify([key, ...keys]));
  },
  deleteKey: (code: string) => {
    const keys = storage.getKeys();
    localStorage.setItem('ahmed_course_keys', JSON.stringify(keys.filter(k => k.code !== code)));
  },
  validateKey: (code: string): boolean => {
    const keys = storage.getKeys();
    return keys.some(k => k.code === code);
  },

  // Stats
  getStats: () => {
    return {
      visits: parseInt(localStorage.getItem('ahmed_visits') || '0'),
      orders: parseInt(localStorage.getItem('ahmed_orders') || '0')
    };
  },
  incrementVisits: () => {
    const visits = parseInt(localStorage.getItem('ahmed_visits') || '0') + 1;
    localStorage.setItem('ahmed_visits', visits.toString());
    return visits;
  },
  incrementOrders: () => {
      // Deprecated in favor of addOrder, but kept for counter compatibility
    const orders = parseInt(localStorage.getItem('ahmed_orders') || '0') + 1;
    localStorage.setItem('ahmed_orders', orders.toString());
    return orders;
  }
};
